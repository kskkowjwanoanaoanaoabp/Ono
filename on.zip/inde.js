const {
    Telegraf, Markup
} = require('telegraf');
const fs = require('fs');
const axios = require('axios');
const JsConfuser = require("js-confuser");

const bot = new Telegraf('7786485494:AAGKMva7fWiJWiSai4ZCdazG0k0R_7OsWt8');

const asciiArt = `
⠄⣾⣿⡇⢸⣿⣿⣿⠄⠈⣿⣿⣿⣿⠈⣿⡇⢹⣿⣿⣿⡇⡇⢸⣿⣿⡇⣿⣿⣿
⢠⣿⣿⡇⢸⣿⣿⣿⡇⠄⢹⣿⣿⣿⡀⣿⣧⢸⣿⣿⣿⠁⡇⢸⣿⣿⠁⣿⣿⣿
⢸⣿⣿⡇⠸⣿⣿⣿⣿⡄⠈⢿⣿⣿⡇⢸⣿⡀⣿⣿⡿⠸⡇⣸⣿⣿⠄⣿⣿⣿
⢸⣿⡿⠷⠄⠿⠿⠿⠟⠓⠰⠘⠿⣿⣿⡈⣿⡇⢹⡟⠰⠦⠁⠈⠉⠋⠄⠻⢿⣿
⢨⡑⠶⡏⠛⠐⠋⠓⠲⠶⣭⣤⣴⣦⣭⣥⣮⣾⣬⣴⡮⠝⠒⠂⠂⠘⠉⠿⠖⣬
⠈⠉⠄⡀⠄⣀⣀⣀⣀⠈⢛⣿⣿⣿⣿⣿⣿⣿⣿⣟⠁⣀⣤⣤⣠⡀⠄⡀⠈⠁
⠄⠠⣾⡀⣾⣿⣧⣼⣿⡿⢠⣿⣿⣿⣿⣿⣿⣿⣿⣧⣼⣿⣧⣼⣿⣿⢀⣿⡇⠄
⡀⠄⠻⣷⡘⢿⣿⣿⡿⢣⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣜⢿⣿⣿⡿⢃⣾⠟⢁⠈
⢃⢻⣶⣬⣿⣶⣬⣥⣶⣿⣿⣿⣿⣿⣿⢿⣿⣿⣿⣿⣿⣷⣶⣶⣾⣿⣷⣾⣾⢣
⡄⠈⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣼⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡏⠘
⣿⡐⠘⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠟⢠⢃
⣿⣷⡀⠈⠻⣿⣿⣿⣿⣿⣿⣿⣿⠿⠿⠿⠿⢿⣿⣿⣿⣿⣿⣿⣿⡿⠋⢀⠆⣼
⣿⣿⣷⡀⠄⠈⠛⢿⣿⣿⣿⣿⣷⣶⣶⣶⣶⣶⣿⣿⣿⣿⣿⠿⠋⠠⠂⢀⣾⣿
⣿⣿⣿⣧⠄⠄⢵⢠⣈⠛⠿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠟⢋⡁⢰⠏⠄⠄⣼⣿⣿
⢻⣿⣿⣿⡄⢢⠨⠄⣯⠄⠄⣌⣉⠛⠻⠟⠛⢋⣉⣤⠄⢸⡇⣨⣤⠄⢸⣿⣿⣿
⡏⠉⠉⠉⠉⠉⠉⠋⠉⠉⠉⠉⠉⠉⠋⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠙⠉⠉⠉⠹
⡇⢸⣿⡟⠛⢿⣷⠀⢸⣿⡟⠛⢿⣷⡄⢸⣿⡇⠀⢸⣿⡇⢸⣿⡇⠀⢸⣿⡇⠀
⡇⢸⣿⣧⣤⣾⠿⠀⢸⣿⣇⣀⣸⡿⠃⢸⣿⡇⠀⢸⣿⡇⢸⣿⣇⣀⣸⣿⡇⠀
⡇⢸⣿⡏⠉⢹⣿⡆⢸⣿⡟⠛⢻⣷⡄⢸⣿⡇⠀⢸⣿⡇⢸⣿⡏⠉⢹⣿⡇⠀
⡇⢸⣿⣧⣤⣼⡿⠃⢸⣿⡇⠀⢸⣿⡇⠸⣿⣧⣤⣼⡿⠁⢸⣿⡇⠀⢸⣿⡇⠀
⣇⣀⣀⣀⣀⣀⣀⣄⣀⣀⣀⣀⣀⣀⣀⣠⣀⡈⠉⣁⣀⣄⣀⣀⣀⣠⣀⣀⣀⣰
                                   
`;

// Log ASCII art to console
console.log(asciiArt);


bot.start((ctx) => {
    ctx.replyWithPhoto('https://files.catbox.moe/5u72ck.jpg', {
        caption: '📄 Welcome to the Obfuscation Bot!\n\nPilih metode obfuscation:',
        parse_mode: 'Markdown',
        ...Markup.inlineKeyboard([
            [Markup.button.callback('🔹 Obfuscation Menu', 'obfmenu')]
        ])
    });
});

bot.action('obfmenu', (ctx) => {
    ctx.reply('🔹 Pilih metode obfuscation:',
    Markup.inlineKeyboard([
        [Markup.button.callback('1️⃣ Basic Obfuscation', 'obf_1')],
        [Markup.button.callback('2️⃣ Advanced Obfuscation', 'obf_2')],
        [Markup.button.callback('3️⃣ String Encryption', 'obf_3')],
        [Markup.button.callback('4️⃣ Minify & Obfuscate', 'obf_4')],
        [Markup.button.callback('5️⃣ Dead Code Injection', 'obf_5')],
        [Markup.button.callback('6️⃣ Variable Renaming', 'obf_6')],
        [Markup.button.callback('7️⃣ Control Flow Flattening', 'obf_7')],
        [Markup.button.callback('8️⃣ Hexadecimal Encoding', 'obf_8')],
        [Markup.button.callback('9️⃣ Function Wrapping', 'obf_9')],
        [Markup.button.callback('🔟 Proxy Functions', 'obf_10')],
        [Markup.button.callback('1️⃣1️⃣ Junk Code Insertion', 'obf_11')],
        [Markup.button.callback('⬅️ Kembali', 'start')]
    ]));
});

// Handler untuk setiap fitur obfuscation
bot.action('obf_1', (ctx) => {
    ctx.reply('📂 Silakan kirim file **.js** yang ingin di-obfuscate dengan metode 1.', {
        parse_mode: 'Markdown'
    });

    bot.on('document', async (msg) => {
        const chatId = msg.chat.id;

        if (!msg.document.file_name.endsWith('.js')) {
            return bot.sendMessage(chatId, '❌ Hanya file **.js** yang bisa diobfuscate!', { parse_mode: 'Markdown' });
        }

        const fileId = msg.document.file_id;
        const fileName = msg.document.file_name;

        try {
            // Ambil file dari Telegram
            const file = await bot.telegram.getFile(fileId);
            const fileLink = `https://api.telegram.org/file/bot${bot.token}/${file.file_path}`;
            const response = await axios.get(fileLink, { responseType: 'arraybuffer' });
            const codeBuffer = Buffer.from(response.data);

            // Simpan file sementara
            const tempFilePath = `./@enc${fileName}`;
            fs.writeFileSync(tempFilePath, codeBuffer);

            // Proses obfuscation dengan metode 1
            bot.telegram.sendMessage(chatId, "⚡️ Memproses encrypt code...");
            const obfuscatedCode = await obf1(codeBuffer.toString());

            // Tambahkan header
            const header = `
/*
Obfuscation Type: 1
Obfuscated by CellaBot
Channel: t.me/isengaja8
*/
`;
            const finalCode = header + obfuscatedCode;

            // Simpan hasil obfuscation
            const encryptedFilePath = `./Obf1_${fileName}`;
            fs.writeFileSync(encryptedFilePath, finalCode);

            // Kirim file obfuscated
            await bot.telegram.sendDocument(chatId, { source: encryptedFilePath }, {
                caption: "```\n" +
                         `📦 Hasil Enkripsi - Metode 1\n` +
                         "----------------------\n" +
                         "📂 File   : " + fileName + "\n" +
                         "🔒 Obfuscated by: CellaBot\n" +
                         "⚙️ Method : Advanced Encryption\n" +
                         "----------------------\n" +
                         "📩 For inquiries: t.me/isengaja8\n" +
                         "```",
                parse_mode: "Markdown",
            });

            // Hapus file sementara
            fs.unlinkSync(tempFilePath);
            fs.unlinkSync(encryptedFilePath);
        } catch (error) {
            console.error("Error:", error);
            bot.telegram.sendMessage(chatId, "❌ Terjadi kesalahan saat mengenkripsi file.");
        }
    });
});
bot.action('obf_2', (ctx) => {
    ctx.reply('📂 Silakan kirim file **.js** yang ingin di-obfuscate dengan metode 2.', {
        parse_mode: 'Markdown'
    });

    bot.on('document', async (msg) => {
        const chatId = msg.chat.id;

        if (!msg.document.file_name.endsWith('.js')) {
            return bot.sendMessage(chatId, '❌ Hanya file **.js** yang bisa diobfuscate!', { parse_mode: 'Markdown' });
        }

        const fileId = msg.document.file_id;
        const fileName = msg.document.file_name;

        try {
            // Ambil file dari Telegram
            const file = await bot.telegram.getFile(fileId);
            const fileLink = `https://api.telegram.org/file/bot${bot.token}/${file.file_path}`;
            const response = await axios.get(fileLink, { responseType: 'arraybuffer' });
            const codeBuffer = Buffer.from(response.data);

            // Simpan file sementara
            const tempFilePath = `./@enc${fileName}`;
            fs.writeFileSync(tempFilePath, codeBuffer);

            // Proses obfuscation dengan metode 2
            bot.telegram.sendMessage(chatId, "⚡️ Memproses encrypt code...");
            const obfuscatedCode = await obf2(codeBuffer.toString());

            // Tambahkan header
            const header = `
/*
Obfuscation Type: 2
Obfuscated by CellaBot
Channel: t.me/isengaja8
*/
`;
            const finalCode = header + obfuscatedCode;

            // Simpan hasil obfuscation
            const encryptedFilePath = `./Obf2_${fileName}`;
            fs.writeFileSync(encryptedFilePath, finalCode);

            // Kirim file obfuscated
            await bot.telegram.sendDocument(chatId, { source: encryptedFilePath }, {
                caption: "```\n" +
                         `📦 Hasil Enkripsi - Metode 2\n` +
                         "----------------------\n" +
                         "📂 File   : " + fileName + "\n" +
                         "🔒 Obfuscated by: CellaBot\n" +
                         "⚙️ Method : Advanced Control Flow\n" +
                         "----------------------\n" +
                         "📩 For inquiries: t.me/isengaja8\n" +
                         "```",
                parse_mode: "Markdown",
            });

            // Hapus file sementara
            fs.unlinkSync(tempFilePath);
            fs.unlinkSync(encryptedFilePath);
        } catch (error) {
            console.error("Error:", error);
            bot.telegram.sendMessage(chatId, "❌ Terjadi kesalahan saat mengenkripsi file.");
        }
    });
});

bot.launch();
console.log('Bot is running...');

bot.launch();

console.log('Bot is running...');

bot.launch();

console.log('Bot is running...');
bot.launch();