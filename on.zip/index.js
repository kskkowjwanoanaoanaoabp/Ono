const fs = require('fs');
const { Telegraf, Markup } = require('telegraf');
const axios = require('axios');
const obfuscateCode = require("./toolsobf"); // Impor semua fungsi obfuscation dari toolsobf.js

const TOKEN = '7786485494:AAGKMva7fWiJWiSai4ZCdazG0k0R_7OsWt8';  // Ganti dengan token bot Anda
const OWNER_ID = '7854185362'; // Ganti dengan ID owner
const USERS_PREMIUM_FILE = 'userspremium.json';
const bot = new Telegraf(TOKEN);

// Load premium users dari file
let usersPremium = {};
if (fs.existsSync(USERS_PREMIUM_FILE)) {
    usersPremium = JSON.parse(fs.readFileSync(USERS_PREMIUM_FILE, 'utf8'));
} else {
    fs.writeFileSync(USERS_PREMIUM_FILE, JSON.stringify({}));
}

// Simpan sesi pengguna
let userSessions = {};

// Banner bot
console.log(`
    🤖 BOT OBFUSCATION STARTED
    🔹 Join: t.me/CellaSpecsArab
`);

// Baca semua metode obfuscation yang tersedia dari `toolsobf.js`
const OBF_METHODS = Object.keys(obfuscateCode);

// Buat command `/obfX` otomatis berdasarkan fungsi di `toolsobf.js`
OBF_METHODS.forEach(type => {
    bot.command(type, (ctx) => {
        const userId = ctx.from.id.toString();

        if (!isPremium(userId)) {
            return ctx.reply('❌ You do not have premium access.');
        }

        userSessions[userId] = { obfuscationType: type };
        ctx.reply(`📄 Please send your .js file for ${type} obfuscation.`);
    });
});

bot.start((ctx) => {
    ctx.replyWithPhoto('https://l.top4top.io/p_3224fc8cq0.jpg', {
        caption: '📄 CellaObfuscated\n\nChoose an option below:\n\n' +
            '/obfmenu - *Obfuscation Menu*',
        parse_mode: 'Markdown'
    });
});

bot.command('obfmenu', (ctx) => {
    ctx.reply('📄 **Obfuscation Menu**:\nPilih metode obfuscation di bawah ini:', {
        parse_mode: 'Markdown',
        ...Markup.inlineKeyboard(
            OBF_METHODS.map(method => [Markup.button.callback(method.toUpperCase(), method)]).concat([
                [Markup.button.callback('🔙 Kembali', 'start')]
            ])
        )
    });
});

// 📌 Handler saat tombol metode obfuscation ditekan
OBF_METHODS.forEach(method => {
    bot.action(method, (ctx) => {
        const userId = ctx.from.id.toString();

        userSessions[userId] = { obfuscationType: method };
        ctx.reply(`📄 Anda memilih ${method.toUpperCase()}. Sekarang, kirimkan file .js untuk diobfuscate.`);
    });
});

// 📌 Proses file JavaScript yang diunggah oleh user
bot.on('document', async (ctx) => {
    const userId = ctx.from.id.toString();

    const fileName = ctx.message.document.file_name;

    if (!fileName.endsWith('.js')) {
        return ctx.reply('❌ Please send a file with the .js extension.');
    }

    if (!userSessions[userId] || !userSessions[userId].obfuscationType) {
        return ctx.reply('❌ Please select an obfuscation type first by using `/obfmenu`.');
    }

    const obfuscationType = userSessions[userId].obfuscationType;

    // Kurangi hari premium
    reducePremiumDays(userId);

    await handleDocumentObfuscation(ctx, obfuscationType);
});

// 📌 Fungsi menangani obfuscation berdasarkan pilihan user
async function handleDocumentObfuscation(ctx, option) {
    const fileId = ctx.message.document.file_id;
    const loadingMessage = await ctx.reply('🚧 Preparing obfuscation...');

    try {
        const fileLink = await ctx.telegram.getFileLink(fileId);
        const code = await downloadFile(fileLink);

        await ctx.telegram.editMessageText(ctx.chat.id, loadingMessage.message_id, undefined, '🔄 Encrypting...');

        if (!obfuscateCode[option]) {
            return ctx.reply('❌ Invalid obfuscation type.');
        }

        const obfuscatedCode = await obfuscateCode[option](code);

        await ctx.telegram.editMessageText(ctx.chat.id, loadingMessage.message_id, undefined, '🎉 Obfuscation complete! Sending file...');
        await ctx.replyWithDocument({ source: Buffer.from(obfuscatedCode), filename: `obfuscated_${option}.js` }, {
            caption: `🔒 Obfuscated using ${option.toUpperCase()}\n\n💡 Free Tools by .@CellaSpecsArab\n📌 Join: t.me/isengaja10`,
            parse_mode: 'Markdown'
        });

    } catch (error) {
        console.error('Error during obfuscation process:', error);
        await ctx.telegram.editMessageText(ctx.chat.id, loadingMessage.message_id, undefined, '❌ An error occurred during obfuscation.');
    }
}

// 📌 Fungsi mengunduh file dari Telegram
async function downloadFile(fileLink) {
    try {
        const response = await axios.get(fileLink);
        return response.data;
    } catch (error) {
        console.error('Error downloading the file:', error);
        throw new Error('Failed to download the file');
    }
}

// 📌 Fungsi mengecek user premium
function isPremium(userId) {
    return usersPremium[userId] && usersPremium[userId].premiumUntil > Date.now();
}

// 📌 Fungsi untuk mengurangi hari premium user
function reducePremiumDays(userId) {
    if (usersPremium[userId] && usersPremium[userId].premiumUntil > Date.now()) {
        usersPremium[userId].premiumUntil -= 24 * 60 * 60 * 1000; // Kurangi 1 hari
        fs.writeFileSync(USERS_PREMIUM_FILE, JSON.stringify(usersPremium));
    } else if (usersPremium[userId]) {
        delete usersPremium[userId]; // Hapus user dari daftar premium
        fs.writeFileSync(USERS_PREMIUM_FILE, JSON.stringify(usersPremium));
    }
}

// Jalankan bot
bot.launch();
console.log('🤖 Bot is running...');